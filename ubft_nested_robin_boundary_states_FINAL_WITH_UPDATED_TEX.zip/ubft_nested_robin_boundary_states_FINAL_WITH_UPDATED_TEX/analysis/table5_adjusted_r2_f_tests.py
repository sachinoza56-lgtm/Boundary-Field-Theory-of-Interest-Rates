#!/usr/bin/env python3
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from scipy.stats import f as f_dist

BASE=Path('/mnt/data/companion_full/ubft_robin_boundary_state_companion_package')
labels_path=BASE/'results/tables/robin_daily_sa_then_sx_double_labels.csv'
raw_path=BASE/'data/input/feds200628_raw.csv'
out_dir=Path('/mnt/data/edit_final/ubft_nested_robin_boundary_states_mrs_gpt_edits_package/tables')
out_dir.mkdir(exist_ok=True)
labels=pd.read_csv(labels_path, parse_dates=['Date'])
labels['state']=labels['sa_sx_double_state'].astype(str)
labels['macro_regime']=labels['regime'].astype(str)
raw=pd.read_csv(raw_path, skiprows=8, na_values=['NA','-999.99'], parse_dates=['Date'])
y_cols=[f'SVENY{i:02d}' for i in range(1,31)]
df=labels[['Date','state','macro_regime']].merge(raw[['Date']+y_cols], on='Date', how='left').sort_values('Date').dropna(subset=['SVENY02','SVENY05','SVENY10','SVENY30']).reset_index(drop=True)
df['slope_2s10s']=df['SVENY10']-df['SVENY02']
df['slope_5s30s']=df['SVENY30']-df['SVENY05']
targets={'10Y level':'SVENY10','2s10s slope':'slope_2s10s','5s30s slope':'slope_5s30s'}

def dummies(s):
    return pd.get_dummies(s.astype(str), drop_first=True).astype(float)

def fit_stats(data, target):
    tmp=data.dropna(subset=[target,'state','macro_regime']).copy()
    y=tmp[target].astype(float).to_numpy()
    Xm=dummies(tmp['macro_regime']).reset_index(drop=True)
    Xs=dummies(tmp['state']).reset_index(drop=True)
    Xms=pd.concat([Xm,Xs],axis=1)
    rows={}
    for name,Xdf in [('macro',Xm),('state',Xs),('macro_plus_state',Xms)]:
        X=Xdf.to_numpy()
        p=X.shape[1]
        if p==0:
            pred=np.full_like(y,y.mean(),dtype=float)
        else:
            pred=LinearRegression().fit(X,y).predict(X)
        resid=y-pred
        sse=float(np.sum(resid**2))
        r2=float(r2_score(y,pred))
        n=len(y)
        adj=1-(1-r2)*(n-1)/(n-p-1)
        rows[name]={'r2':r2,'adj_r2':adj,'sse':sse,'p':p,'n':n}
    # nested F: macro restricted vs macro+state unrestricted
    r=rows['macro']; u=rows['macro_plus_state']
    df1=u['p']-r['p']
    df2=u['n']-u['p']-1
    F=((r['sse']-u['sse'])/df1)/(u['sse']/df2)
    pval=float(f_dist.sf(F, df1, df2))
    return { 'n':u['n'], 'p_macro':r['p'], 'p_state_added':df1, 'p_macro_plus_state':u['p'],
            'macro_r2':r['r2'], 'macro_adj_r2':r['adj_r2'],
            'state_r2':rows['state']['r2'], 'state_adj_r2':rows['state']['adj_r2'],
            'macro_plus_state_r2':u['r2'], 'macro_plus_state_adj_r2':u['adj_r2'],
            'incremental_r2':u['r2']-r['r2'],
            'incremental_adj_r2':u['adj_r2']-r['adj_r2'],
            'nested_F_state_block':float(F), 'df_num':int(df1), 'df_den':int(df2), 'nested_F_pvalue':pval}

rows=[]
for label,target in targets.items():
    d=fit_stats(df,target)
    d.update({'target':label,'target_variable':target})
    rows.append(d)
res=pd.DataFrame(rows)
cols=['target','target_variable','n','p_macro','p_state_added','p_macro_plus_state','macro_r2','macro_adj_r2','state_r2','state_adj_r2','macro_plus_state_r2','macro_plus_state_adj_r2','incremental_r2','incremental_adj_r2','nested_F_state_block','df_num','df_den','nested_F_pvalue']
res=res[cols]
res.to_csv(out_dir/'macro_adjusted_curve_shape_adjusted_r2_f_tests.csv',index=False)
print(res.to_string(index=False))
