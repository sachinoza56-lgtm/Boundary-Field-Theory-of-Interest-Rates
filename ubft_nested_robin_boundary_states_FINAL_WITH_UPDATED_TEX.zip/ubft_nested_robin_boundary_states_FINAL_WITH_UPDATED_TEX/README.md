# Nested Robin Boundary States - final refined draft package

This package contains the refined companion-note draft and supporting materials.

## Main files
- `ubft_nested_robin_boundary_states_final_refined.pdf` - compiled PDF draft.
- `ubft_nested_robin_boundary_states_final_refined.tex` - LaTeX source.
- `empirical_test_4A_user_reference.pdf` - user-provided reference PDF.
- `contact_sheet_final_refined.jpg` - visual render contact sheet used for layout QA.

## Folders
- `figures/` - figures used in the paper.
- `tables/` - CSV outputs supporting the paper tables and diagnostics.
- `analysis/` - analysis outputs and helper script(s), including the adjusted R2 / nested F-test check for Table 5.

## Key refinements in this version
- Clarifies that the note is a standalone companion working paper, not a replacement for Paper IV.
- States the nested-state construction more explicitly: inherited first-stage (s,A) assignments; fixed-seed, within-segment GMM subdivision in standardized (s,X); post-label diagnostics only.
- Adds a caveat for small negative chi estimates in some short/belly volatility states.
- Adds degrees-of-freedom, adjusted R2, and nested F-test support for the macro-adjusted Table 5 results.
- Softens the Paper III maturity-loading connection as empirical consistency rather than derivation.
- Adds a state-construction summary appendix table.
